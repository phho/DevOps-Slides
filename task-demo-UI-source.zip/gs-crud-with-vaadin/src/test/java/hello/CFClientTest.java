package hello;

import java.util.List;

import org.cloudfoundry.client.CloudFoundryClient;
import org.cloudfoundry.client.v3.applications.GetApplicationTaskRequest;
import org.cloudfoundry.client.v3.applications.ListApplicationTasksRequest;
import org.cloudfoundry.client.v3.tasks.CreateTaskRequest;
import org.cloudfoundry.client.v3.tasks.CreateTaskResponse;
import org.cloudfoundry.client.v3.tasks.GetTaskRequest;
import org.cloudfoundry.client.v3.tasks.GetTaskResponse;
import org.cloudfoundry.client.v3.tasks.ListTasksRequest;
import org.cloudfoundry.client.v3.tasks.TaskResource;
import org.cloudfoundry.reactor.DefaultConnectionContext;
import org.cloudfoundry.reactor.client.ReactorCloudFoundryClient;
import org.cloudfoundry.reactor.tokenprovider.PasswordGrantTokenProvider;
import org.junit.Before;
import org.junit.Test;

public class CFClientTest {

	private CloudFoundryClient cfClient;
	
	@Before
	public void setup() {
		DefaultConnectionContext connectionContext = DefaultConnectionContext.builder()
        .apiHost("api.local.pcfdev.io").skipSslValidation(true)
        .build();
		PasswordGrantTokenProvider passwordToken = PasswordGrantTokenProvider.builder()
		        .password("admin")
		        .username("admin")
		        .build();
		cfClient = ReactorCloudFoundryClient.builder()
        .connectionContext(connectionContext)
        .tokenProvider(passwordToken)
        .build();
	}
	
	@Test
	public void testQuery() {
//		List<TaskResource> taskResList = cfClient.tasks().list(ListTasksRequest.builder().build()).block().getResources();
//		for (TaskResource taskRes : taskResList) {
//			System.out.println(taskRes);
//			System.out.println(taskRes.getCommand());
//		}
		
//		GetTaskResponse getTaskRes = cfClient.tasks().get(GetTaskRequest.builder().taskId("c8d08d7a-3512-4472-9655-3f896c9dfe90").build()).block();
//		System.out.println(getTaskRes);
//		System.out.println(getTaskRes.getCommand());
//		System.out.println(getTaskRes.getCreatedAt());
//		System.out.println(getTaskRes.getName());
//		System.out.println(getTaskRes.getId());
//		System.out.println(getTaskRes.getUpdatedAt());
//		System.out.println(getTaskRes.getMemoryInMb());
//		System.out.println(getTaskRes.getResult());
//		System.out.println(getTaskRes.getState());
//		List<TaskResource> taskResList2 = cfClient.applicationsV3().listTasks(ListApplicationTasksRequest.builder().applicationId("8b8c6e8c-fe8e-4a22-bdfe-6088c4c046b9").build()).block().getResources();
		CreateTaskResponse createTaskResponse = cfClient.tasks().create(CreateTaskRequest.builder().applicationId("8b8c6e8c-fe8e-4a22-bdfe-6088c4c046b9").command("sleep 65536").name("api2").memoryInMb(16048).build()).block();
		System.out.println(createTaskResponse.getId());
		System.out.println(cfClient.tasks().get(GetTaskRequest.builder().taskId(createTaskResponse.getId()).build()).block());
	}
}
