package hello;

import java.util.ArrayList;
import java.util.List;

import org.cloudfoundry.client.CloudFoundryClient;
import org.cloudfoundry.client.v3.tasks.CancelTaskRequest;
import org.cloudfoundry.client.v3.tasks.CreateTaskRequest;
import org.cloudfoundry.client.v3.tasks.CreateTaskResponse;
import org.cloudfoundry.client.v3.tasks.GetTaskRequest;
import org.cloudfoundry.client.v3.tasks.GetTaskResponse;
import org.cloudfoundry.client.v3.tasks.ListTasksRequest;
import org.cloudfoundry.client.v3.tasks.TaskResource;
import org.cloudfoundry.reactor.ConnectionContext;
import org.cloudfoundry.reactor.DefaultConnectionContext;
import org.cloudfoundry.reactor.TokenProvider;
import org.cloudfoundry.reactor.client.ReactorCloudFoundryClient;
import org.cloudfoundry.reactor.tokenprovider.PasswordGrantTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

public class TaskRepository {

	private static CloudFoundryClient cfClient;
	static {
		DefaultConnectionContext connectionContext = DefaultConnectionContext.builder()
				.apiHost("api.local.pcfdev.io").skipSslValidation(true)
				.build();
		PasswordGrantTokenProvider passwordToken = PasswordGrantTokenProvider.builder()
				.password("admin")
				.username("admin")
				.build();
		cfClient = ReactorCloudFoundryClient.builder()
				.connectionContext(connectionContext)
				.tokenProvider(passwordToken)
				.build();
	}
	public List<Task> findAll() {
		List<Task> taskList = new ArrayList<Task>();
		List<TaskResource> taskResList = cfClient.tasks().list(ListTasksRequest.builder().build()).block().getResources();
		for (TaskResource taskRes : taskResList) {
//			System.out.println(taskRes);
//			System.out.println(taskRes.getCommand());
			GetTaskResponse getTaskRes = cfClient.tasks().get(GetTaskRequest.builder().taskId(taskRes.getId()).build()).block();
			Task task = new Task();
			task.setCommand(getTaskRes.getCommand());
			task.setCreatedAt(getTaskRes.getCreatedAt());
			task.setFailureReason(getTaskRes.getResult().getFailureReason());
			task.setId(getTaskRes.getId());
			task.setMemoryInMb(getTaskRes.getMemoryInMb());
			task.setName(getTaskRes.getName());
			task.setState(getTaskRes.getState().getValue());
			task.setUpdatedAt(getTaskRes.getUpdatedAt());
			taskList.add(task);
		}
		return taskList;
	}
	
	public List<Task> findByTaskNameStartsWithIgnoreCase(String pattern) {
		List<Task> taskList = findAll();
		List<Task> filteredList = new ArrayList<Task>();
		for (Task t : taskList) {
			if (t.getName().contains(pattern)) {
				filteredList.add(t);
			}
		}
		return filteredList;
	}
	
	public Task findOne(String id) {
		GetTaskResponse getTaskRes = cfClient.tasks().get(GetTaskRequest.builder().taskId(id).build()).block();
		Task task = new Task();
		task.setCommand(getTaskRes.getCommand());
		task.setCreatedAt(getTaskRes.getCreatedAt());
		task.setFailureReason(getTaskRes.getResult().getFailureReason());
		task.setId(getTaskRes.getId());
		task.setMemoryInMb(getTaskRes.getMemoryInMb());
		task.setName(getTaskRes.getName());
		task.setState(getTaskRes.getState().getValue());
		task.setUpdatedAt(getTaskRes.getUpdatedAt());
		return task;
	}
	
	public void submit(Task task) {
		System.out.println(task);
		CreateTaskResponse createTaskResponse = cfClient.tasks().create(CreateTaskRequest.builder().applicationId("8b8c6e8c-fe8e-4a22-bdfe-6088c4c046b9").command(task.getCommand()).name(task.getName()).memoryInMb(task.getMemoryInMb()).build()).block();
		System.out.println(createTaskResponse.getId());
		System.out.println(cfClient.tasks().get(GetTaskRequest.builder().taskId(createTaskResponse.getId()).build()).block());
	}
	
	public void terminate(Task task) {
		System.out.println(task);
		cfClient.tasks().cancel(CancelTaskRequest.builder().taskId(task.getId()).build()).block();
		
	}

	//	@Bean
	//	DefaultConnectionContext connectionContext(
	//			@Value("${api.host:https://api.local.pcfdev.io}") String apiHost) {
	//	    return DefaultConnectionContext.builder()
	//	        .apiHost(apiHost).skipSslValidation(true)
	//	        .build();
	//	}
	//
	//	@Bean
	//	PasswordGrantTokenProvider tokenProvider(@Value("${cf.username:admin}") String username,
	//	                                         @Value("${cf.password:admin}") String password) {
	//	    return PasswordGrantTokenProvider.builder()
	//	        .password(password)
	//	        .username(username)
	//	        .build();
	//	}
	//	
	//	@Bean
	//	@Autowired
	//	ReactorCloudFoundryClient cloudFoundryClient(ConnectionContext connectionContext, TokenProvider tokenProvider) {
	//	    return ReactorCloudFoundryClient.builder()
	//	        .connectionContext(connectionContext)
	//	        .tokenProvider(tokenProvider)
	//	        .build();
	//	}
}
